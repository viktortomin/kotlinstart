package org.example

fun main(args: Array<String>) {
    printResult(4,3, Int::pow)
}

fun printResult(value1: Int, value2: Int, action: Int.(Int) -> Int) {
    println(value1.action(value2))
}

fun Int.pow(n: Int): Int {
    var ans = 1
    for (i in 1..n) {
        ans *= this
    }
    return ans
}

sealed class DataType

class DoubleType(val value: Double) : DataType()

class UnitType : DataType()

fun Any.displayTypeInfo(): String {
    if (this is Int) {
        return "это Int"
    } else if (this is String) {
        return "это String"
    } else if (this is DataType) {
        return this.displayDataTypeInfo()
    }else{
        return "тип у true неизвестен"
    }

}
fun DataType.displayDataTypeInfo(): String {
    if (this is DoubleType){
        return "это DoubleType со значением $value"
    }else{
        return "это Unit"
    }
}