package org.example

import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.math.cos
import kotlin.math.sin


fun main(args: Array<String>) {
    val a = Point(1.0, 1.0)
    val b = Point(2.0, 2.0)
    val c = Point(3.0, 1.0)
    val pr = Triangle(a, b, c)
    println(pr.print())
    println(pr.perimetr())
    println(pr.ploshad())
    println(pr.turn_atound(30.0).print())
}
class CollinearException(messege: String = "Точки лежат на одной прямой") : IllegalArgumentException(messege)

class Triangle(val a: Point, b: Point, val c: Point) {
    init {
        if(a.collin(b, c)){
            throw CollinearException()
        }
    }

    private var _b: Point = b

    var b: Point
        get() = _b
        set(value) {
            if(a.collin(b, c)){
                throw CollinearException()
            }
            _b = value
        }

    fun print(): String {
        return("Треугольник с вершинами: ${a.vap()}, ${b.vap()}, ${c.vap()}")
    }
    fun perimetr(): Double {
        val ab = sqrt((a.x - b.x).pow(2) + (a.y - b.y).pow(2))
        val ac = sqrt((a.x - c.x).pow(2) + (a.y - c.y).pow(2))
        val cb = sqrt((c.x - b.x).pow(2) + (c.y - b.y).pow(2))
        return(ab + ac + cb)
    }
    fun ploshad(): Double {
        val ab = sqrt((a.x - b.x).pow(2) + (a.y - b.y).pow(2))
        val ac = sqrt((a.x - c.x).pow(2) + (a.y - c.y).pow(2))
        val cb = sqrt((c.x - b.x).pow(2) + (c.y - b.y).pow(2))
        val per = ab + ac + cb
        return(sqrt(per * (per - ab) * (per - ac) * (per - cb)))
    }
    fun turn_atound(angle: Double): Triangle {
        val center_x = (a.x + b.x + c.x) / 3.0
        val center_y = (a.y + b.y + c.y) / 3.0
        val a1 = Point((a.x - center_x), (a.y - center_y))
        val b1 = Point((b.x - center_x), (b.y - center_y))
        val c1 = Point((c.x - center_x), (c.y - center_y))

        val a2 = Point(((a1.x * cos(angle)) - a1.y * sin(angle)), ((a1.x * sin(angle)) + a1.y * cos(angle)))
        val b2 = Point(((b1.x * cos(angle)) - b1.y * sin(angle)), ((b1.x * sin(angle)) + b1.y * cos(angle)))
        val c2 = Point(((c1.x * cos(angle)) - c1.y * sin(angle)), ((c1.x * sin(angle)) + c1.y * cos(angle)))

        val a3 = Point(a2.x + center_x, a2.y + center_y)
        val b3 = Point(b2.x + center_x, b2.y + center_y)
        val c3 = Point(c2.x + center_x, c2.y + center_y)
        
        val ans = Triangle(a3, b3, c3)
        return ans

    }
}

class Point(val x: Double, val y: Double) {
    fun vap(): String {
        return("($x, $y)")
    }
    fun x(): Double{
        return x
    }
    fun y(): Double{
        return y
    }
    fun collin(b: Point, c: Point): Boolean {
        if((y / x == b.y / b.x) and (b.y / b.x == c.y / c.x)) return true
        return false
    }
}
